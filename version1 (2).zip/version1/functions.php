<?php
function virat_theme_assets() {
    // Enqueue main CSS
    wp_enqueue_style('virat-style', get_template_directory_uri() . '/assets/styles.css');

    // Enqueue main JS
    wp_enqueue_script('virat-script', get_template_directory_uri() . '/assets/script.js', array(), null, true);

    // Path to assets folder
    $assets_dir = get_template_directory() . '/assets';
    $assets_url = get_template_directory_uri() . '/assets';

    // Scan all files in assets folder (images, css, js, etc.)
    $files = scandir($assets_dir);

    $assets = array();

    foreach ($files as $file) {
        if ($file === '.' || $file === '..') continue;

        // Only include image types (you can add more extensions if needed)
        if (preg_match('/\.(jpg|jpeg|png|gif|svg)$/i', $file)) {
            $name = pathinfo($file, PATHINFO_FILENAME); // filename without extension
            $assets[$name] = $assets_url . '/' . $file;
        }
    }

    // Pass to JS
    wp_localize_script('virat-script', 'virat_images', $assets);
}
add_action('wp_enqueue_scripts', 'virat_theme_assets');
