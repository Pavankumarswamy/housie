<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>Tambola-Tron | Lovable Generated Project</title>

    <!-- Favicon -->
    <link rel="icon" type="image/png" href="/assets/favicon.png">

    <!-- SEO Meta -->
    <meta name="description" content="Tambola-Tron: A Lovable Generated Project offering an engaging and interactive experience.">
    <meta name="author" content="Lovable">
    <meta name="keywords" content="Tambola-Tron, Lovable, Interactive Project, Web Application, Online Game">
    <meta name="robots" content="index, follow">

    <!-- Google Fonts (Optional for Enhanced Typography) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <!-- Open Graph -->
    <meta property="og:title" content="Tambola-Tron | Lovable Generated Project">
    <meta property="og:description" content="Discover Tambola-Tron, an interactive project by Lovable designed for an engaging user experience.">
    <meta property="og:type" content="website">
    <meta property="og:url" content="https://tambola-tron.lovable.dev/">
    <meta property="og:image" content="https://lovable.dev/opengraph-image-p98pqg.png">
    <meta property="og:site_name" content="Tambola-Tron">
    <meta property="og:locale" content="en_US">

    <!-- Twitter -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="Tambola-Tron | Lovable Generated Project">
    <meta name="twitter:description" content="Discover Tambola-Tron, an interactive project by Lovable designed for an engaging user experience.">
    <meta name="twitter:image" content="https://lovable.dev/opengraph-image-p98pqg.png">
    <meta name="twitter:site" content="@lovable_dev">

    <!-- Schema.org Markup -->
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "WebApplication",
      "name": "Tambola-Tron",
      "url": "https://tambola-tron.lovable.dev/",
      "description": "Tambola-Tron: A Lovable Generated Project offering an engaging and interactive experience.",
      "creator": {
        "@type": "Organization",
        "name": "Lovable",
        "url": "https://lovable.dev/"
      },
      "applicationCategory": "Game"
    }
    </script>

    <!-- Preload Critical Assets -->
    <link rel="preload" href="/assets/script.js" as="script">
    <link rel="preload" href="/assets/styles.css" as="style">

    <!-- Load Assets -->
    <script type="module" crossorigin defer src="/assets/script.js"></script>
    <link rel="stylesheet" crossorigin href="/assets/styles.css">
  </head>

  <body role="document">
    <div id="root" aria-live="polite"></div>
  </body>
</html>